package Plane_Component_package;

public abstract class PrivateCompartment extends PlaneComponent{

  PrivateCompartment(){
    System.out.println("PrivateCompartement just created!");
  }

}
